import "./styles.scss";

// Get the first list and adds items
let firstUl = document.querySelector("#firstUl");

for (let i = 0; i < 5; i++) {
  const listItem = document.createElement("li");
  listItem.innerText = `Item ${i + 1}`;
  firstUl.appendChild(listItem);
}
// Changes the text in the <p>-element
let txtEl = document.querySelector("#txt");
txtEl.innerText = "Hello World!";
// Remove and add elements in the list
// Function that removes the list-element when the button is clicked
function remove() {
  this.parentNode.parentNode.removeChild(this.parentNode);
}
// Gets the list
let secondUl = document.querySelector("#secondUl");
// Gives the existing "remove"-buttons in the list an eventlistener
[...secondUl.children].forEach((item) => {
  item.firstElementChild.addEventListener("click", remove);
});
// Gets the "add"-button
let addBtn = document.querySelector("#addBtn");
// Gives the "add"-button an eventlistener
addBtn.addEventListener("click", function () {
  // Creates a listitem and a button
  const listItem = document.createElement("li");
  const btn = document.createElement("button");
  // Gives the elements text
  listItem.innerText = "New Item ";
  btn.innerText = "Remove";
  // Gives the button an listener so it can remove the listitem
  btn.addEventListener("click", remove);
  // Appends the button to the listitem
  listItem.appendChild(btn);
  // Appends the listitem to the list
  secondUl.appendChild(listItem);
});
// Writes the text from input-element inside the form-element
function msg(event) {
  event.preventDefault(); // Prevents page refresh
  let elements = this.elements; // Gets the elements inside the form
  alert(elements[0].value); // Writes the text inside input in the alert message
  elements[0].value = ""; // Removes old text inside input field
}
// Gets the form-element and adds a listener
let form = document.querySelector("form");
form.addEventListener("submit", msg);

/*
 * Function that cycles through the elements inside the list.
 * Removes the class from the active element and adds it to the
 * previous or next sibling, depending on which button has been
 * clicked on.
 */
function carousel() {
  let items = traverse.children;
  for (let i = 0; i < items.length; i++) {
    if (items[i].className === "active") {
      items[i].classList.remove("active");
      if (this.id === "prev") {
        if (items[i].previousElementSibling === null) {
          traverse.lastElementChild.classList.add("active");
        } else {
          items[i].previousElementSibling.classList.add("active");
        }
      }

      if (this.id === "next") {
        if (items[i].nextElementSibling === null) {
          traverse.firstElementChild.classList.add("active");
        } else {
          items[i].nextElementSibling.classList.add("active");
        }
      }
      return;
    }
  }
}
// Gets the <ul>-element
let traverse = document.querySelector("#traverse");
// Gives listeners to the "prev"- and "next"-buttons
document.querySelector("#prev").addEventListener("click", carousel);
document.querySelector("#next").addEventListener("click", carousel);

// Listens for change in the input-element
document.querySelector("#input").oninput = () => {
  const label = document.querySelector("#label");
  label.style.display = "block";
  setTimeout(() => {
    label.style.display = "none";
  }, 500);
};
